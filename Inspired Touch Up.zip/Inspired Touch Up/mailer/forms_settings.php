<?php
	/* Forms settings */
	$subj = "New message from 'Inspired Touch-Up'"; //letter subject
	$to = 'parth@udaykhimjigroup.com'; // Enter Your E-mail
	$from = 'salesm@inspire-d.me'; // Admin e-mail
	$fromName = 'I:T'; // Your company name
	$charset = 'UTF-8';
?>
